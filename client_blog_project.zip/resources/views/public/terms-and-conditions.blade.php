@extends('layouts/main')

@section('head')
    <meta name="keywords" content="Privacy policy">
    <meta name="description" content="">
    <title>Privacy Policy</title>
<link rel="stylesheet" href="{{css_path('Privacy-Policy.css')}}" media="screen">
 @endsection


 @section('main')
     

    <section class="u-clearfix u-section-1" id="sec-72ab">
      <div class="u-clearfix u-sheet u-sheet-1">
        <h1 class="u-align-center u-custom-font u-font-source-sans-pro u-text u-title u-text-1">terms and conditions</h1>
      </div>
    </section>
    <section class="u-clearfix u-grey-10 u-section-2" id="sec-3d09">
      <div class="u-clearfix u-sheet u-sheet-1">
        <p class="u-align-center u-large-text u-text u-text-variant u-text-1">Your Ad Here</p>
      </div>
    </section>
    <section class="u-clearfix u-section-3" id="sec-54c8">
      <div class="u-clearfix u-sheet u-sheet-1">
        <div class="u-clearfix u-custom-html u-expanded-width u-custom-html-1">
         
        
        
        
        
        </div>
      </div>
    </section>
    
    @endsection
    