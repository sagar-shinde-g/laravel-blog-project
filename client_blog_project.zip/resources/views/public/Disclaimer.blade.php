@extends('layouts/main')

@section('head')
    <meta name="keywords" content="Disclaimer">
    <meta name="description" content="">
    <title>Disclaimer</title>
    <link rel="stylesheet" href="nicepage.css" media="screen">
<link rel="stylesheet" href="{{css_path('Disclaimer.css')}}" media="screen">
@endsection

@section('main')
    

    <section class="u-clearfix u-grey-10 u-section-1" id="sec-0bec">
      <div class="u-clearfix u-sheet u-sheet-1">
        <p class="u-align-center u-large-text u-text u-text-variant u-text-1">Your Ad Here</p>
      </div>
    </section>
    <section class="u-clearfix u-section-2" id="sec-d0cc">
      <div class="u-clearfix u-sheet u-sheet-1">
        <h1 class="u-align-center u-custom-font u-font-source-sans-pro u-text u-title u-text-1">Disclaimer</h1>
      </div>
    </section>
    <section class="u-clearfix u-section-3" id="sec-e386">
      <div class="u-clearfix u-sheet u-sheet-1">
        <div class="u-clearfix u-custom-html u-expanded-width u-custom-html-1">



        </div>
      </div>
    </section>

    @endsection