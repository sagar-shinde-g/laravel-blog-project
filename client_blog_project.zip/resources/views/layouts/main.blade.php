@include('layouts/header')
@yield('main')
@include('layouts/footer')