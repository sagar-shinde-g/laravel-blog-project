@include('layouts/no-header')
@include('layouts/admin-nav')

@yield('main')

