<section class="u-clearfix u-section-1" id="sec-11bc">
  <div class="u-clearfix u-sheet u-sheet-1">
    <div class="u-container-style u-expanded-width u-group u-white u-group-1">
      <div class="u-container-layout u-container-layout-1">
        <nav class="u-align-left u-menu u-menu-hamburger u-offcanvas u-menu-1" data-responsive-from="XL">
          <div class="menu-collapse">
            <a class="u-button-style u-file-icon u-nav-link u-file-icon-1" href="#">
              <img src="{{img_path('6339029.png')}}" alt="">
            </a>
          </div>
          <div class="u-custom-menu u-nav-container">
            <ul class="u-nav u-unstyled"><li class="u-nav-item"><a class="u-button-style u-nav-link" href="{{url('/admin/setting')}}">Site Setting</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="{{url('/admin/category')}}">Category</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="{{url('/admin/blog')}}">Blog</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="{{url('/admin/ads')}}">ads</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="{{url('/admin/contacts')}}">Contacts</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="{{url('/admin/logout')}}" >Logout</a>
</li></ul>
          </div>
          <div class="u-custom-menu u-nav-container-collapse">
            <div class="u-black u-container-style u-inner-container-layout u-opacity u-opacity-95 u-sidenav">
              <div class="u-inner-container-layout u-sidenav-overflow">
                <div class="u-menu-close"></div>
                <ul class="u-align-center u-nav u-popupmenu-items u-unstyled u-nav-2"><li class="u-nav-item"><a class="u-button-style u-nav-link" href="{{url('/admin/setting')}}">Site Setting</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="{{url('/admin/category')}}">Category</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="{{url('/admin/blog')}}">Blog</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="{{url('/admin/ads')}}">ads</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="{{url('/admin/contacts')}}">Contacts</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="{{url('/admin/logout')}}">Logout</a>
</li></ul>
              </div>
            </div>
            <div class="u-black u-menu-overlay u-opacity u-opacity-70"></div>
          </div>
        </nav>
        <p class="u-large-text u-text u-text-default u-text-variant u-text-1">welcome back ! Admin</p>
      </div>
    </div>
  </div>
  <script>
    function dltclick(a) {

        document.getElementById('sub-' + a).click();
    }
</script>
</section>