
<footer class="u-align-center u-clearfix u-footer u-grey-80 u-footer" id="sec-ba73"><div class="u-clearfix u-sheet u-sheet-1">
    <p class="u-small-text u-text u-text-variant u-text-1">Sample text. Click to select the Text Element.</p>
  </div></footer>
  <script class="u-script" type="text/javascript" src="{{js_path('jquery.js')}}" "="" defer=""></script>
  <script class="u-script" type="text/javascript" src="{{js_path('nicepage.js')}}" "="" defer=""></script>
  
</body></html>