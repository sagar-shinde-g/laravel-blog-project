<?php echo $__env->make('layouts/no-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts/admin-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('main'); ?>

<?php /**PATH C:\xampp\htdocs\client_blog_project\resources\views/layouts/admin-main.blade.php ENDPATH**/ ?>