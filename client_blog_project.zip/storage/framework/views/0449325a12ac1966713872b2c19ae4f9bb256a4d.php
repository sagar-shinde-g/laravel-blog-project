<?php $__env->startSection('head'); ?>
    <meta name="keywords"
        content="Trending, ​Your most unhappy customers are your greatest source of learning., ​Your most unhappy customers are your greatest source of learning., ​Your most unhappy customers are your greatest source of learning., ​Your most unhappy customers are your greatest source of learning., ​Your most unhappy customers are your greatest source of learning., Recent Posts, ​​Your most unhappy customers are your greatest source of learning., ​​Your most unhappy customers are your greatest source of learning., ​​Your most unhappy customers are your greatest source of learning., ​​Your most unhappy customers are your greatest source of learning., ​​Your most unhappy customers are your greatest source of learning., ​​Your most unhappy customers are your greatest source of learning., Popular Posts, ​​Your most unhappy customers are your greatest source of learning., ​​Your most unhappy customers are your greatest source of learning., ​​Your most unhappy customers are your greatest source of learning., ​​Your most unhappy customers are your greatest source of learning., ​​Your most unhappy customers are your greatest source of learning., ​​Your most unhappy customers are your greatest source of learning., Categories, ​&nbsp;guruji&nbsp;&nbsp;mysipkar">
    <meta name="description" content="">
    <title>Home</title>
    <link rel="stylesheet" href="<?php echo e(css_path('Home.css')); ?>" media="screen">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main'); ?>
    
    
            
        
    <section class="u-clearfix u-section-3" id="carousel_0567">
        <div class="u-clearfix u-sheet u-valign-middle u-sheet-1">
            <h1 class="u-align-center u-text u-text-1">Recent Posts</h1>
        </div>
    </section>
    <section class="u-clearfix u-grey-10 u-section-4" id="sec-01f7">
        <div class="u-clearfix u-sheet u-sheet-1">
            <p class="u-align-center u-large-text u-text u-text-variant u-text-1">Your Ad Here</p>
        </div>
    </section>
    <section class="u-clearfix u-section-5" id="sec-ba47">
        <div class="u-clearfix u-sheet u-sheet-1">
            <div class="u-expanded-width u-list u-list-1">
                <div class="u-repeater u-repeater-1">


                    <?php
                        $recent_6_post = app('App\Http\Controllers\indexController')->get_recent_6_posts();
                    ?>


                    <?php $__currentLoopData = $recent_6_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="u-container-style u-custom-item u-list-item u-repeater-item">
                            <div class="u-container-layout u-similar-container u-container-layout-1">
                                <img style="background-color: gray" class="u-expanded-width u-image u-image-round u-radius-10 u-image-1"
                                    src="<?php echo e($item->image); ?>" alt="" data-image-width="1280"
                                    data-image-height="921">
                                <p class="u-align-center u-text u-text-1">
                                    <?php echo e($item->category . ' | ' . substr($item->updated_at, 0, 2 + 2 + 2 + 1 + 4)); ?></p>
                                <h1 class="u-align-left u-custom-font u-font-pt-sans u-text u-title u-text-2">
                                    <?php echo e($item->post_title); ?></h1>
                                <p class="u-align-left u-text u-text-3"><?php echo e($item->description); ?><span
                                        style="font-size: 1.125rem;">
                                        <span style="font-size: 1rem;"></span>
                                    </span>
                                </p>
                                <a href="<?php echo e(url('/blogs/' . $item->str_url)); ?>"
                                    class="u-align-center u-border-2 u-border-black u-btn u-button-style u-hover-black u-none u-text-hover-white u-btn-1">Read
                                    more</a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </section>
    <section class="u-clearfix u-section-6" id="sec-5e3d">
        <div class="u-clearfix u-sheet u-sheet-1">
            <a href="https://nicepage.com"
                class="u-border-none u-btn u-btn-round u-button-style u-custom-color-1 u-hover-palette-3-base u-radius-50 u-btn-1">Load
                more</a>
        </div>
    </section>
    
    <section class="u-clearfix u-section-9" id="carousel_e3f0">
        <div class="u-clearfix u-sheet u-valign-middle u-sheet-1">
            <h1 class="u-align-center u-text u-text-1">Popular Posts</h1>
        </div>
    </section>
    <section class="u-clearfix u-section-10" id="carousel_50e2">
        <div class="u-clearfix u-sheet u-sheet-1">
            <div class="u-expanded-width u-list u-list-1" id="last">

                <div class="u-repeater u-repeater-1">
                    <?php
                        $popular_posts = app('App\Http\Controllers\indexController')->get_recent_6_posts();
                    ?>


                    <?php $__currentLoopData = $popular_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="u-container-style u-list-item u-repeater-item">
                            <div class="u-container-layout u-similar-container u-container-layout-1">
                                <img style="background-color: gray" class="u-expanded-width u-image u-image-round u-radius-10 u-image-1"
                                    src="<?php echo e($item->image); ?>" alt="" data-image-width="1280"
                                    data-image-height="921">
                                <p class="u-align-center u-text u-text-1">
                                    <?php echo e($item->category . ' | ' . substr($item->updated_at, 0, 2 + 2 + 2 + 1 + 4)); ?></p>
                                <h1 class="u-align-left u-custom-font u-font-pt-sans u-text u-title u-text-2">
                                    <?php echo e($item->post_title); ?></h1>
                                <p class="u-align-left u-text u-text-3"><?php echo e($item->description); ?><span
                                        style="font-size: 1.125rem;">
                                        <span style="font-size: 1rem;"></span>
                                    </span>
                                </p>
                                <a href="<?php echo e(url('/blogs/' . $item->str_url)); ?>"
                                    class="u-align-center u-border-2 u-border-black u-btn u-button-style u-hover-black u-none u-text-hover-white u-btn-1">Read
                                    more</a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                  </div>

                </div>



            </div>
        </div>
    </section>
    <section class="u-clearfix u-section-11" id="carousel_5484">
        <div class="u-clearfix u-sheet u-valign-middle u-sheet-1">
            <h1 class="u-align-center u-text u-text-1">Categories</h1>
        </div>
    </section>
    <section class="u-clearfix u-section-12" id="sec-4b7b">
        <div class="u-clearfix u-sheet u-sheet-1">
            <h2 class="u-custom-font u-font-pt-sans u-subtitle u-text u-text-1">
              <?php
              $category = app('App\Http\Controllers\indexController')->all_category();
          ?>
              
              <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
      
              
              <a style="margin: 5px;"
                    href="<?php echo e(url('/category/'.$item->category_name)); ?>"
                    class="u-border-none u-btn u-button-style u-custom-color-1 u-text-body-alt-color u-btn-2"><?php echo e($item->category_name); ?></a>
                  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </h2>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\client_blog_project\resources\views/public/index.blade.php ENDPATH**/ ?>