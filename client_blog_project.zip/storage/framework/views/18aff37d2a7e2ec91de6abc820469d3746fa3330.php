<!DOCTYPE html>
<html style="font-size: 16px;" lang="en"><head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
   
<link rel="stylesheet" href="<?php echo e(css_path('nicepage.css')); ?>" media="screen">
   <?php echo $__env->yieldContent('head'); ?>
   <script class="u-script" type="text/javascript" src="<?php echo e(js_path('jquery.js')); ?>" "="" defer=""></script>
  <script class="u-script" type="text/javascript" src="<?php echo e(js_path('nicepage.js')); ?>" "="" defer=""></script>
  
  </head>
  <body class="u-body u-xl-mode" data-lang="en"> <?php /**PATH C:\xampp\htdocs\client_blog_project\resources\views/layouts/no-header.blade.php ENDPATH**/ ?>